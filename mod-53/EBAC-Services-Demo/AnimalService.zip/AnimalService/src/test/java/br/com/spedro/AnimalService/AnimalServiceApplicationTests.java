package br.com.spedro.AnimalService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
